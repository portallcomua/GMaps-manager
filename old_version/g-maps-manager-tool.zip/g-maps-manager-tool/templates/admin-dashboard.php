<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="wrap">
    <h1>🗺️ Диспетчер заявок Google Business Profile</h1>
    
    <!-- Повідомлення про статуси -->
    <?php if ( isset($_GET['settings_saved']) ) : ?>
        <div class="updated"><p>Налаштування ключів успішно збережено!</p></div>
    <?php endif; ?>
    <?php if ( isset($_GET['oauth']) && $_GET['oauth'] === 'success' ) : ?>
        <div class="updated"><p>Сайт успішно зв'язано з вашим Google Business акаунтом!</p></div>
    <?php endif; ?>

    <!-- ТАБЛИЦЯ ЗАМОВЛЕНЬ -->
    <table class="wp-list-table widefat fixed striping posts" style="margin-top: 20px;">
        <thead>
            <tr>
                <th style="width: 20%;">Бізнес / Клієнт</th>
                <th style="width: 30%;">Основні дані</th>
                <th style="width: 25%;">Медіа</th>
                <th style="width: 15%;">Статус оплати</th>
                <th style="width: 10%;">Дія</th>
            </tr>
        </thead>
        <tbody>
            <?php if ( empty( $orders ) ) : ?>
                <tr><td colspan="5">Заявок поки немає. Очікуйте на перших клієнтів!</td></tr>
            <?php else : ?>
                <?php foreach ( $orders as $order ) : 
                    $order_id = $order->ID;
                    $google_name = get_post_meta( $order_id, '_google_biz_name', true );
                    $category = get_post_meta( $order_id, '_biz_category', true );
                    $desc = get_post_meta( $order_id, '_biz_description', true );
                    $phone = get_post_meta( $order_id, '_biz_phone', true );
                    $hours = get_post_meta( $order_id, '_biz_hours', true );
                    $pay_status = get_post_meta( $order_id, '_payment_status', true );
                    $logo_id = get_post_meta( $order_id, '_biz_logo_attachment_id', true );
                    $store_id = get_post_meta( $order_id, '_biz_storefront_attachment_id', true );
                ?>
                    <tr>
                        <td><strong><?php echo esc_html( $order->post_title ); ?></strong></td>
                        <td>
                            <p><strong>Категорія:</strong> <?php echo esc_html($category); ?></p>
                            <p><strong>Тел:</strong> <?php echo esc_html($phone); ?></p>
                        </td>
                        <td>
                            <?php if ( $logo_id ) echo wp_get_attachment_image( $logo_id, array(40, 40) ); ?>
                            <?php if ( $store_id ) echo wp_get_attachment_image( $store_id, array(40, 40) ); ?>
                        </td>
                        <td><?php echo ($pay_status === 'paid') ? '💰 Оплачено' : '⏳ Очікує'; ?></td>
                        <td><button class="button button-small" disabled>В Google</button></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- БЛОК НАЛАШТУВАНЬ КЛЮЧІВ -->
    <div style="margin-top: 40px; background: #fff; padding: 20px; border: 1px solid #ccd0d4; max-width: 600px;">
        <h2>⚙️ Налаштування інтеграції з Google Cloud</h2>
        <form method="POST" action="">
            <?php wp_nonce_field( 'g_maps_settings_nonce' ); ?>
            
            <p>
                <label><strong>Google Client ID:</strong></label><br>
                <input type="text" name="g_maps_client_id" value="<?php echo esc_attr($client_id); ?>" style="width: 100%;">
            </p>
            
            <p>
                <label><strong>Google Client Secret:</strong></label><br>
                <input type="password" name="g_maps_client_secret" value="<?php echo esc_attr($client_secret); ?>" style="width: 100%;">
            </p>
            
            <p>
                <input type="submit" name="save_g_maps_settings" class="button button-primary" value="Зберегти ключі">
            </p>
        </form>

        <hr style="margin: 20px 0;">
        
        <h3>Статус підключення: <?php echo $has_token; ?></h3>
        <?php if ( !empty($client_id) && !empty($client_secret) ) : ?>
            <a href="<?php echo esc_url($auth_url); ?>" class="button button-secondary">🔗 Авторизувати мій робочий Google Акаунт</a>
            <p class="description">*Натисніть після збереження ключів, щоб надати сайту дозвіл керувати картами.</p>
        <?php endif; ?>
    </div>
</div>
