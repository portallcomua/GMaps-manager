<?php
/**
 * Шаблон Кабінету Клієнта (Версія з підтримкою мобільної камери та рефералів)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Перевіряємо, чи є реферал у Cookie (якщо клієнт прийшов по лінку менеджера)
$referrer_manager = isset($_COOKIE['g_maps_ref_manager']) ? sanitize_text_field($_COOKIE['g_maps_ref_manager']) : '';
?>

<div class="g-maps-client-container" style="max-width: 800px; margin: 0 auto; font-family: sans-serif; padding: 10px;">
    <h2>🗺️ Налаштування вашого Google Business Profile</h2>
    
    <!-- ПОПЕРЕДЖЕННЯ ПРО ВЕРИФІКАЦІЮ -->
    <div class="g-maps-notice" style="background: #fff8e1; border-left: 4px solid #ffb300; padding: 15px; margin-bottom: 25px; border-radius: 4px;">
        <h3 style="margin-top: 0; color: #b78103;">⚠️ Важлива інформація про модерацію Google</h3>
        <p style="font-size: 14px; line-height: 1.5; color: #333; margin-bottom: 5px;">
            Створення бізнес-точок повністю контролюється Google. Будь ласка, заповнюйте анкету максимально точно.
        </p>
        <ul style="font-size: 13px; line-height: 1.6; color: #444; padding-left: 20px; margin-top: 5px;">
            <li><strong>Фото вивіски:</strong> На кроці №3 ви можете завантажити фото з пам'яті або <strong>зробити знімок камери прямо зараз</strong>. Реальне фото фасаду знижує ризик блокування на 80%.</li>
            <li><strong>Відеоверифікація:</strong> Якщо Google попросить підтвердження, вам потрібно буде зняти коротке відео вашого бізнесу за інструкціями нашого менеджера.</li>
        </ul>
    </div>

    <!-- ТАБИ -->
    <div class="g-maps-tabs" style="margin-bottom: 20px; display: flex; flex-wrap: wrap; gap: 5px;">
        <button class="tab-btn active" onclick="openTab(event, 'step-auth')" style="padding: 10px; cursor:pointer;">1. Доступ</button>
        <button class="tab-btn" onclick="openTab(event, 'step-info')" style="padding: 10px; cursor:pointer;">2. Дані</button>
        <button class="tab-btn" onclick="openTab(event, 'step-media')" style="padding: 10px; cursor:pointer;">3. Медіа</button>
        <button class="tab-btn" onclick="openTab(event, 'step-payment')" style="padding: 10px; cursor:pointer;">4. Оплата</button>
    </div>

    <form id="g-maps-order-form" method="POST" enctype="multipart/form-data">
        
        <!-- Приховане поле менеджера для реферальної системи -->
        <input type="hidden" name="referrer_manager_id" value="<?php echo esc_attr($referrer_manager); ?>">
        
        <!-- КРОК 1 -->
        <div id="step-auth" class="tab-content active">
            <h3>Зв'язок з вашим Google-акаунтом</h3>
            <p>Введіть назву компанії, якщо вона вже колись створювалась на картах:</p>
            <input type="text" name="google_biz_name" placeholder="Наприклад: Кав'ярня 'Арома' Київ" style="width: 100%; padding: 10px; margin-bottom: 15px; box-sizing: border-box;">
            <br>
            <button type="button" class="button button-primary" id="request-google-access" style="padding: 10px 15px;">🤖 Надати права менеджменту майстру</button>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">*Запит надійде автоматично. Вам потрібно буде лише підтвердити його у своєму Google-акаунті.</p>
        </div>

        <!-- КРОК 2 -->
        <div id="step-info" class="tab-content" style="display:none;">
            <h3>Основна інформація</h3>
            <p><label><strong>Точна назва для Карт:</strong></label><br>
            <input type="text" name="biz_final_name" style="width: 100%; padding: 10px; box-sizing: border-box;" required></p>

            <p><label><strong>Категорія бізнесу:</strong></label><br>
            <input type="text" name="biz_category" placeholder="Наприклад: Салон краси, СТО, Кафе" style="width: 100%; padding: 10px; box-sizing: border-box;" required></p>

            <p><label><strong>Опис компанії (до 750 символів):</strong></label><br>
            <textarea name="biz_description" rows="4" placeholder="Опишіть ваші послуги..." style="width: 100%; padding: 10px; box-sizing: border-box;"></textarea></p>

            <p><label><strong>Телефон для клієнтів на Карті:</strong></label><br>
            <input type="tel" name="biz_phone" style="width: 100%; padding: 10px; box-sizing: border-box;" required></p>

            <p><label><strong>Графік роботи:</strong></label><br>
            <input type="text" name="biz_hours" placeholder="Пн-Пт: 09:00 - 18:00, Сб: 10:00 - 16:00" style="width: 100%; padding: 10px; box-sizing: border-box;"></p>
        </div>

        <!-- КРОК 3: ЗАВАНТАЖЕННЯ ФОТО / КАМЕРА -->
        <div id="step-media" class="tab-content" style="display:none;">
            <h3>Завантаження фотоматеріалів</h3>
            
            <p>
                <label><strong>Логотип компанії (або квадратне фото):</strong></label><br>
                <input type="file" name="biz_logo" accept="image/*">
            </p>

            <p style="background: #f0f0f0; padding: 10px; border-radius: 4px;">
                <label><strong>📸 Фото вивіски або входу (Зробіть фото прямо зараз або виберіть з файлів):</strong></label><br>
                <input type="file" name="biz_storefront" accept="image/*" capture="environment" style="margin-top: 8px;">
                <br><small style="color: #666;">*На смартфонах ця кнопка одразу запустить основну камеру телефону.</small>
            </p>

            <p>
                <label><strong>Додаткові фото (інтер'єр, товари):</strong></label><br>
                <input type="file" name="biz_photos[]" accept="image/*" multiple>
            </p>
        </div>

        <!-- КРОК 4 -->
        <div id="step-payment" class="tab-content" style="display:none;">
            <h3>Фінальний крок: Оплата та відправка</h3>
            <p>Після успішної оплати ваша анкета миттєво з'явиться на робочому столі вашого менеджера.</p>
            
            <div class="payment-options" style="margin: 20px 0;">
                <a href="https://payhip.com" 
                   class="payhip-buy-button" 
                   data-theme="blue" 
                   data-product="s12Lx"
                   style="background: #007cba; color: #fff; padding: 12px 20px; text-decoration: none; border-radius: 4px; display: inline-block; margin-bottom: 10px; font-weight: bold;">
                   💳 Оплатити послугу налаштування
                </a>
            </div>
            
            <br>
            <input type="submit" name="save_g_maps_order" class="button button-primary" value="🚀 Надіслати анкету майстру" style="font-size: 16px; padding: 12px 25px; background: #46b450; border: none; color: #fff; border-radius: 4px; cursor: pointer;">
        </div>

    </form>
</div>

<script>
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tab-content");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tab-btn");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].style.background = "#e0e0e0";
        tablinks[i].style.fontWeight = "normal";
    }
    document.getElementById(tabName).style.display = "block";
    if(evt && evt.currentTarget) {
        evt.currentTarget.style.background = "#fff";
        evt.currentTarget.style.fontWeight = "bold";
    }
}
</script>
