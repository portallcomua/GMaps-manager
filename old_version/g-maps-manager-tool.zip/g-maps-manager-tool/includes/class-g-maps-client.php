<?php
/**
 * Клас керування кабінетом клієнта та реферальною системою Cookie
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GMapsClient {

    public function __construct() {
        add_action( 'init', array( $this, 'register_orders_post_type' ) );
        // Хук для перехоплення реферального посилання при візиті клієнта
        add_action( 'wp', array( $this, 'catch_manager_referral' ) );
        add_action( 'wp_loaded', array( $this, 'handle_client_form_submission' ) );
        add_shortcode( 'g_maps_client_dashboard', array( $this, 'render_client_dashboard' ) );
    }

    public function register_orders_post_type() {
        register_post_type( 'g_maps_order', array(
            'labels' => array(
                'name'          => 'Заявки G-Maps',
                'singular_name' => 'Заявка G-Maps',
            ),
            'public'      => false,
            'show_ui'     => true,
            'supports'    => array( 'title' ),
        ) );
    }

    /**
     * Функція ловить менеджерський ?ref= і записує куку власнику закладу
     */
    public function catch_manager_referral() {
        if ( isset( $_GET['ref'] ) ) {
            $manager_id = sanitize_text_field( $_GET['ref'] );
            // Записуємо Cookie на 30 днів (30 * DAY_IN_SECONDS)
            setcookie( 'g_maps_ref_manager', $manager_id, time() + ( 30 * DAY_IN_SECONDS ), COOKIEPATH, COOKIE_DOMAIN );
        }
    }

    public function render_client_dashboard() {
        if ( ! is_user_logged_in() ) {
            return '<p>Будь ласка, <a href="' . wp_login_url() . '">авторизуйтесь через Google</a> для заповнення анкети.</p>';
        }
        ob_start();
        include G_MAPS_TOOL_PATH . 'templates/client-dashboard.php';
        return ob_get_clean();
    }

    public function handle_client_form_submission() {
        if ( ! isset( $_POST['save_g_maps_order'] ) || ! is_user_logged_in() ) {
            return;
        }

        $user_id  = get_current_user_id();
        $biz_name = sanitize_text_field( $_POST['biz_final_name'] );
        
        // Визначаємо, який менеджер привів цього клієнта (з форми або з куки)
        $manager_id = !empty($_POST['referrer_manager_id']) ? sanitize_text_field($_POST['referrer_manager_id']) : '';
        if ( empty($manager_id) && isset($_COOKIE['g_maps_ref_manager']) ) {
            $manager_id = sanitize_text_field($_COOKIE['g_maps_ref_manager']);
        }

        $order_id = wp_insert_post( array(
            'post_title'  => 'Заявка: ' . $biz_name,
            'post_status' => 'pending',
            'post_type'   => 'g_maps_order',
        ) );

        if ( is_wp_error( $order_id ) ) return;

        // Мета-дані компанії
        update_post_meta( $order_id, '_google_biz_name', sanitize_text_field( $_POST['google_biz_name'] ) );
        update_post_meta( $order_id, '_biz_category', sanitize_text_field( $_POST['biz_category'] ) );
        update_post_meta( $order_id, '_biz_description', sanitize_textarea_field( $_POST['biz_description'] ) );
        update_post_meta( $order_id, '_biz_phone', sanitize_text_field( $_POST['biz_phone'] ) );
        update_post_meta( $order_id, '_biz_hours', sanitize_text_field( $_POST['biz_hours'] ) );
        update_post_meta( $order_id, '_client_user_id', $user_id );
        update_post_meta( $order_id, '_payment_status', 'unpaid' );
        
        // ЗАКРІПЛЮЄМО МЕНЕДЖЕРА ЗА ЗАЯВКОЮ
        if ( !empty($manager_id) ) {
            update_post_meta( $order_id, '_assigned_manager_id', $manager_id );
        }

        // Завантаження файлів (Лого та Вивіска з Камери)
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );

        if ( ! empty( $_FILES['biz_logo']['name'] ) ) {
            $logo_id = media_handle_upload( 'biz_logo', $order_id );
            if ( ! is_wp_error( $logo_id ) ) update_post_meta( $order_id, '_biz_logo_attachment_id', $logo_id );
        }

        // Обробка фото з камери
        if ( ! empty( $_FILES['biz_storefront']['name'] ) ) {
            $storefront_id = media_handle_upload( 'biz_storefront', $order_id );
            if ( ! is_wp_error( $storefront_id ) ) update_post_meta( $order_id, '_biz_storefront_attachment_id', $storefront_id );
        }

        // Очищаємо реферальну куку після успішного оформлення
        setcookie( 'g_maps_ref_manager', '', time() - YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN );

        wp_redirect( add_query_arg( 'status', 'success', wp_get_referer() ) );
        exit;
    }
}
new GMapsClient();

