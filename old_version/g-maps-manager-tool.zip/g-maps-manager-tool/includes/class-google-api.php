<?php
/**
 * Клас для інтеграції з Google API (Версія з повними лінками)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GoogleMapsAPI {

    // Отримання збережених налаштувань
    public static function get_credentials() {
        return array(
            'client_id'     => get_option( 'g_maps_client_id', '' ),
            'client_secret' => get_option( 'g_maps_client_secret', '' ),
        );
    }

    // Генерація посилання для авторизації в Google
    public static function get_auth_url() {
        $creds = self::get_credentials();
        if ( empty( $creds['client_id'] ) ) return '#';

        $redirect_uri = admin_url( 'admin.php?page=g-maps-admin-panel' );
        
        $params = array(
            'client_id'       => $creds['client_id'],
            'redirect_uri'    => $redirect_uri,
            'response_type'   => 'code',
            'scope'           => 'https://googleapis.com/auth/business.manage',
            'access_type'     => 'offline',
            'prompt'          => 'consent'
        );

        return 'https://google.com/o/oauth2/v2/auth?' . http_build_query( $params );
    }

    // Обмін коду авторизації на постійний Токен доступу
    public static function fetch_access_token( $code ) {
        $creds = self::get_credentials();
        $redirect_uri = admin_url( 'admin.php?page=g-maps-admin-panel' );

        $token_url = 'https://googleapis.com/token';

        $response = wp_remote_post( $token_url, array(
            'body' => array(
                'code'          => $code,
                'client_id'     => $creds['client_id'],
                'client_secret' => $creds['client_secret'],
                'redirect_uri'  => $redirect_uri,
                'grant_type'    => 'authorization_code',
            )
        ) );

        if ( is_wp_error( $response ) ) return false;

        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        
        if ( isset( $data['access_token'] ) ) {
            update_option( 'g_maps_access_token', $data['access_token'] );
            if ( isset( $data['refresh_token'] ) ) {
                update_option( 'g_maps_refresh_token', $data['refresh_token'] );
            }
            return true;
        }
        return false;
    }
}
