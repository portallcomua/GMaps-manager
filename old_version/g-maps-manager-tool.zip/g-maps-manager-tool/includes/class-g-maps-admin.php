<?php
/**
 * Клас керування кабінетом адміністратора (Оновлений)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GMapsAdmin {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_admin_menu_page' ) );
        add_action( 'admin_init', array( $this, 'handle_admin_settings_and_oauth' ) );
    }

    public function add_admin_menu_page() {
        add_menu_page(
            'G-Maps Замовлення',
            '🛡️ G-Maps Панель',
            'manage_options',
            'g-maps-admin-panel',
            array( $this, 'render_admin_panel' ),
            'dashicons-location-alt',
            25
        );
    }

    public function handle_admin_settings_and_oauth() {
        // 1. Збереження ключів з адмінки
        if ( isset( $_POST['save_g_maps_settings'] ) && check_admin_referer( 'g_maps_settings_nonce' ) ) {
            update_option( 'g_maps_client_id', sanitize_text_field( $_POST['g_maps_client_id'] ) );
            update_option( 'g_maps_client_secret', sanitize_text_field( $_POST['g_maps_client_secret'] ) );
            wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&settings_saved=1' ) );
            exit;
        }

        // 2. Обробка повернення від Google після авторизації адміна
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'g-maps-admin-panel' && isset( $_GET['code'] ) ) {
            $code = sanitize_text_field( $_GET['code'] );
            $success = GoogleMapsAPI::fetch_access_token( $code );
            wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&oauth=' . ( $success ? 'success' : 'failed' ) ) );
            exit;
        }
    }

    public function render_admin_panel() {
        // Отримуємо заявки
        $orders = get_posts( array(
            'post_type'   => 'g_maps_order',
            'post_status' => 'any',
            'numberposts' => -1,
        ) );

        // Налаштування ключів
        $client_id = get_option( 'g_maps_client_id', '' );
        $client_secret = get_option( 'g_maps_client_secret', '' );
        $has_token = get_option( 'g_maps_access_token', '' ) ? '✅ Підключено' : '❌ Не підключено';
        $auth_url = GoogleMapsAPI::get_auth_url();

        include G_MAPS_TOOL_PATH . 'templates/admin-dashboard.php';
    }
}
new GMapsAdmin();
