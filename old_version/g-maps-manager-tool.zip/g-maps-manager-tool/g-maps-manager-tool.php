<?php
/**
 * Plugin Name: GMaps manager
 * Plugin URI:  https://github.com/portallcomua/GMaps-manager.git
 * Description: Автоматизація створення, редагування та менеджменту Google Business Profile для клієнтів та партнерської мережі заробітку.
 * Version:     1.0.0
 * Author:      UAServer
 * Author URI:  https://uaserver.pp.ua/
 * Text Domain: gmaps-manager
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Вихід, якщо викликано напряму
}

// Головні константи плагіна
define( 'G_MAPS_VERSION', '1.0.0' );
define( 'G_MAPS_TOOL_PATH', plugin_dir_path( __FILE__ ) );
define( 'G_MAPS_TOOL_URL', plugin_dir_url( __FILE__ ) );
define( 'G_MAPS_GITHUB_REPO', 'portallcomua/GMaps-manager' );
define( 'G_MAPS_PAYHIP_DEFAULT_CREATION', 's12Lx' ); // Ваше посилання Payhip

// Підключаємо ядро та модулі
require_once G_MAPS_TOOL_PATH . 'includes/class-google-api.php';
require_once G_MAPS_TOOL_PATH . 'includes/class-g-maps-client.php';
require_once G_MAPS_TOOL_PATH . 'includes/class-g-maps-admin.php';

/**
 * Ініціалізація головного класу GMaps Manager
 */
class GMapsManager {
    
    public function __construct() {
        // Реєстрація активації та деактивації
        register_activation_hook( __FILE__, array( $this, 'activate_plugin' ) );
        
        // Скрипти для фронтенду та адмінки
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_client_assets' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
        
        // Ініціалізація механізму автооновлень з GitHub
        add_action( 'init', array( $this, 'init_github_updates' ) );
    }

    /**
     * Дії при активації плагіна (створення ролей, налаштувань)
     */
    public function activate_plugin() {
        // Створюємо кастомну роль "Менеджер карт" для вашої майбутньої SaaS-мережі
        add_role( 'g_maps_manager', 'Менеджер GMaps', array(
            'read'         => true,
            'edit_posts'   => false,
            'delete_posts' => false,
        ) );
        
        // Записуємо дефолтне посилання Payhip в опції
        if ( ! get_option( 'g_maps_payhip_id' ) ) {
            update_option( 'g_maps_payhip_id', G_MAPS_PAYHIP_DEFAULT_CREATION );
        }
    }

    /**
     * Підключення CSS/JS для кабінету клієнта
     */
    public function enqueue_client_assets() {
        wp_enqueue_style( 'g-maps-client-style', G_MAPS_TOOL_URL . 'assets/client.css', array(), G_MAPS_VERSION );
        // Скрипт Payhip для стильних вікон оплати поверх сайту
        wp_enqueue_script( 'payhip-js', 'https://payhip.com', array(), null, false );
    }

    /**
     * Підключення стилів для адмінки
     */
    public function enqueue_admin_assets() {
        wp_enqueue_style( 'g-maps-admin-style', G_MAPS_TOOL_URL . 'assets/admin.css', array(), G_MAPS_VERSION );
    }

    /**
     * Підготовка під автооновлення з GitHub та додавання на WordPress.org
     */
    public function init_github_updates() {
        // Цей блок залишається для підключення лінкера оновлень (наприклад, за допомогою платформи ReleaseHub або кастомного хука)
        // Коли ви завантажите плагін на GitHub, ми додамо сюди легкий скрипт перевірки нових релізів.
    }
}

// Запуск системи
new GMapsManager();
