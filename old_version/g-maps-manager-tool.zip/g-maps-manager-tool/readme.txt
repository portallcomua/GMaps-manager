=== GMaps manager ===
Contributors: UAServer
Tags: google maps, google business profile, gmb, saas, business local
Requires at least: 6.0
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later

Автоматизація роботи з Google Business Profile. Кабінет клієнта, інтеграція з Payhip та платформа для заробітку менеджерів.

== Description ==
Плагін дозволяє автоматизувати збір даних від клієнтів для створення точок на картах Google Maps, приймати оплату через Payhip та керувати процесом з єдиної панелі керування WordPress через офіційне Google API.

== Installation ==
1. Завантажте папку в `/wp-content/plugins/`
2. Активуйте плагін в адмінці WordPress
3. Перейдіть в "🛡️ G-Maps Панель" та налаштуйте Google API ключі.
