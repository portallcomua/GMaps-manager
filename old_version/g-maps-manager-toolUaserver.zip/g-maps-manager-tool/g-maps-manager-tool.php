<?php
/**
 * Plugin Name: GMaps Manager
 * Plugin URI:  https://github.com/portallcomua/GMaps-manager.git
 * Description: Автоматизація створення, редагування та менеджменту Google Business Profile для клієнтів та партнерської мережі заробітку.
 * Version:     1.0.1
 * Author:      UAServer
 * Author URI:  https://uaserver.pp.ua/
 * Text Domain: gmaps-manager
 * Domain Path: /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Головні константи плагіна
define( 'G_MAPS_VERSION', '1.0.1' );
define( 'G_MAPS_TOOL_PATH', plugin_dir_path( __FILE__ ) );
define( 'G_MAPS_TOOL_URL', plugin_dir_url( __FILE__ ) );
define( 'G_MAPS_GITHUB_REPO', 'portallcomua/GMaps-manager' );
define( 'G_MAPS_PAYHIP_PRODUCT_ID', 's12Lx' );
define( 'G_MAPS_PAYHIP_URL', 'https://payhip.com/b/' . G_MAPS_PAYHIP_PRODUCT_ID );

// Підключаємо ядро та модулі з перевіркою наявності файлів
$includes = array(
	'includes/class-google-api.php',
	'includes/class-g-maps-client.php',
	'includes/class-g-maps-admin.php'
);

foreach ( $includes as $file ) {
	$file_path = G_MAPS_TOOL_PATH . $file;
	if ( file_exists( $file_path ) ) {
		require_once $file_path;
	} else {
		error_log( 'GMaps Manager: Файл не знайдено - ' . $file_path );
	}
}

/**
 * Головний клас GMaps Manager
 */
class GMapsManager {
    
    public function __construct() {
        register_activation_hook( __FILE__, array( $this, 'activate_plugin' ) );
        
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_client_assets' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
        
        add_action( 'init', array( $this, 'init_github_updates' ) );
    }

    public function activate_plugin() {
        add_role( 'g_maps_manager', 'Менеджер GMaps', array(
            'read'         => true,
            'edit_posts'   => false,
            'delete_posts' => false,
        ) );
        
        if ( ! get_option( 'g_maps_payhip_id' ) ) {
            update_option( 'g_maps_payhip_id', G_MAPS_PAYHIP_PRODUCT_ID );
        }
    }

    public function enqueue_client_assets() {
        wp_enqueue_style( 'g-maps-client-style', G_MAPS_TOOL_URL . 'assets/client.css', array(), G_MAPS_VERSION );
    }

    public function enqueue_admin_assets() {
        wp_enqueue_style( 'g-maps-admin-style', G_MAPS_TOOL_URL . 'assets/admin.css', array(), G_MAPS_VERSION );
    }

    public function init_github_updates() {
        // Місце для майбутнього механізму оновлень з GitHub
    }
}

new GMapsManager();