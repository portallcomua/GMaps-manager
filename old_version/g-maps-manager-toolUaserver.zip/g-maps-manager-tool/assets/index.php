<?php
// Тиша — мовчання — безпека
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}