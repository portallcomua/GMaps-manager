<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="wrap">
    <h1>🗺️ Диспетчер заявок Google Business Profile</h1>
    
    <?php if ( isset($_GET['settings_saved']) ) : ?>
        <div class="updated"><p>Налаштування ключів успішно збережено!</p></div>
    <?php endif; ?>
    <?php if ( isset($_GET['oauth']) && $_GET['oauth'] === 'success' ) : ?>
        <div class="updated"><p>Сайт успішно зв'язано з вашим Google Business акаунтом!</p></div>
    <?php elseif ( isset($_GET['oauth']) && $_GET['oauth'] === 'failed' ) : ?>
        <div class="error"><p>Помилка авторизації. Спробуйте ще раз.</p></div>
    <?php endif; ?>

    <!-- ПОВІДОМЛЕННЯ ПРО ПУБЛІКАЦІЮ В GOOGLE -->
    <?php if ( isset($_GET['publish']) && $_GET['publish'] === 'success' ) : ?>
        <div class="updated"><p>✅ Бізнес-профіль успішно створено в Google! Профіль з'явиться в Google Maps протягом 30 хвилин - 3 днів.</p></div>
    <?php elseif ( isset($_GET['publish']) && $_GET['publish'] === 'failed' ) : ?>
        <div class="error">
            <p>❌ Помилка публікації: <?php echo isset($_GET['reason']) ? esc_html( urldecode( $_GET['reason'] ) ) : 'невідома помилка'; ?></p>
        </div>
    <?php endif; ?>

    <!-- ТАБЛИЦЯ ЗАМОВЛЕНЬ -->
    <table class="wp-list-table widefat fixed striped posts" style="margin-top: 20px;">
        <thead>
            <tr>
                <th style="width: 15%;">Бізнес / Клієнт</th>
                <th style="width: 25%;">Основні дані</th>
                <th style="width: 20%;">Медіа</th>
                <th style="width: 15%;">Статус оплати</th>
                <th style="width: 25%;">Дія</th>
            </tr>
        </thead>
        <tbody>
            <?php if ( empty( $orders ) ) : ?>
                <tr><td colspan="5">Заявок поки немає. Очікуйте на перших клієнтів!</td></tr>
            <?php else : ?>
                <?php foreach ( $orders as $order ) : 
                    $order_id = $order->ID;
                    $google_name = get_post_meta( $order_id, '_google_biz_name', true );
                    $category = get_post_meta( $order_id, '_biz_category', true );
                    $desc = get_post_meta( $order_id, '_biz_description', true );
                    $phone = get_post_meta( $order_id, '_biz_phone', true );
                    $hours = get_post_meta( $order_id, '_biz_hours', true );
                    $pay_status = get_post_meta( $order_id, '_payment_status', true );
                    $logo_id = get_post_meta( $order_id, '_biz_logo_attachment_id', true );
                    $store_id = get_post_meta( $order_id, '_biz_storefront_attachment_id', true );
                    $manager_id = get_post_meta( $order_id, '_assigned_manager_id', true );
                    $place_id = get_post_meta( $order_id, '_google_place_id', true );
                ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html( $order->post_title ); ?></strong>
                            <?php if ( $manager_id ) : ?>
                                <br><small>Менеджер: #<?php echo esc_html( $manager_id ); ?></small>
                            <?php endif; ?>
                            <?php if ( $place_id ) : ?>
                                <br><small style="color: #46b450;">✅ В Google</small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <p><strong>Категорія:</strong> <?php echo esc_html($category); ?></p>
                            <p><strong>Тел:</strong> <?php echo esc_html($phone); ?></p>
                            <p><small><?php echo esc_html($google_name); ?></small></p>
                        </td>
                        <td>
                            <?php if ( $logo_id ) echo wp_get_attachment_image( $logo_id, array(40, 40) ); ?>
                            <?php if ( $store_id ) echo wp_get_attachment_image( $store_id, array(40, 40) ); ?>
                        </td>
                        <td>
                            <?php if ( $pay_status === 'paid' ) : ?>
                                <span class="badge-paid">💰 Оплачено</span>
                            <?php else : ?>
                                <span class="badge-pending">⏳ Очікує</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( empty( $place_id ) ) : ?>
                                <form method="POST" style="display:inline;">
                                    <?php wp_nonce_field( 'g_maps_publish_action' ); ?>
                                    <input type="hidden" name="order_id" value="<?php echo esc_attr($order_id); ?>">
                                    <button type="submit" name="publish_to_google" class="button button-primary" style="background: #007cba; border-color: #007cba;">
                                        🚀 В Google
                                    </button>
                                </form>
                            <?php else : ?>
                                <a href="https://www.google.com/maps/place/?q=place_id:<?php echo esc_attr($place_id); ?>" target="_blank" class="button button-secondary">
                                    👁️ Переглянути
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- БЛОК НАЛАШТУВАНЬ КЛЮЧІВ -->
    <div class="g-maps-settings-box">
        <h2>⚙️ Налаштування інтеграції з Google Cloud</h2>
        <form method="POST" action="">
            <?php wp_nonce_field( 'g_maps_settings_nonce' ); ?>
            
            <p>
                <label><strong>Google Client ID:</strong></label><br>
                <input type="text" name="g_maps_client_id" value="<?php echo esc_attr($client_id); ?>" style="width: 100%;">
            </p>
            
            <p>
                <label><strong>Google Client Secret:</strong></label><br>
                <input type="password" name="g_maps_client_secret" value="<?php echo esc_attr($client_secret); ?>" style="width: 100%;">
            </p>
            
            <p>
                <input type="submit" name="save_g_maps_settings" class="button button-primary" value="Зберегти ключі">
            </p>
        </form>

        <hr style="margin: 20px 0;">
        
        <h3>Статус підключення: 
            <span class="<?php echo get_option('g_maps_access_token') ? 'status-connected' : 'status-disconnected'; ?>">
                <?php echo $has_token; ?>
            </span>
        </h3>
        <?php if ( ! empty($client_id) && ! empty($client_secret) ) : ?>
            <a href="<?php echo esc_url($auth_url); ?>" class="button button-secondary">🔗 Авторизувати мій робочий Google Акаунт</a>
            <p class="description">*Натисніть після збереження ключів, щоб надати сайту дозвіл керувати картами.</p>
        <?php endif; ?>
    </div>
</div>