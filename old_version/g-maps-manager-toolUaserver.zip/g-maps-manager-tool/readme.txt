=== GMaps Manager ===
Contributors: UAServer
Donate link: https://uaserver.pp.ua/
Tags: google maps, business profile, seo, local business
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Автоматизація створення, редагування та менеджменту Google Business Profile для клієнтів та партнерської мережі заробітку.

== Description ==
GMaps Manager — це потужний інструмент для керування Google Business Profile через WordPress.

* Створення заявок клієнтами
* Реферальна система для менеджерів
* Інтеграція з Google API
* Оплата через Payhip

== Installation ==
1. Завантажте архів плагіна.
2. Розпакуйте його в папку `/wp-content/plugins/`.
3. Активуйте плагін через меню "Плагіни" в WordPress.
4. Налаштуйте Google API ключі в адмін-панелі.

== Changelog ==
= 1.0.1 =
* Виправлено помилки Google OAuth URL
* Додано refresh_token
* Виправлено посилання Payhip
* Додано nonce для безпеки

= 1.0.0 =
* Перший реліз