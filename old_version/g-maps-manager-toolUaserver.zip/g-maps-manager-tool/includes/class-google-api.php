<?php
/**
 * Клас для інтеграції з Google API (ВИПРАВЛЕНО + ДОДАНО МЕТОД)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GoogleMapsAPI {

    public static function get_credentials() {
        return array(
            'client_id'     => get_option( 'g_maps_client_id', '' ),
            'client_secret' => get_option( 'g_maps_client_secret', '' ),
        );
    }

    public static function get_auth_url() {
        $creds = self::get_credentials();
        if ( empty( $creds['client_id'] ) ) return '#';
        
        $state = wp_generate_password( 32, false );
        set_transient( 'g_maps_oauth_state', $state, 600 );

        $redirect_uri = admin_url( 'admin.php?page=g-maps-admin-panel' );
        
        $params = array(
            'client_id'       => $creds['client_id'],
            'redirect_uri'    => $redirect_uri,
            'response_type'   => 'code',
            'scope'           => 'https://www.googleapis.com/auth/business.manage',
            'access_type'     => 'offline',
            'prompt'          => 'consent',
            'state'           => $state
        );

        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query( $params );
    }

    public static function fetch_access_token( $code ) {
        $creds = self::get_credentials();
        $redirect_uri = admin_url( 'admin.php?page=g-maps-admin-panel' );

        if ( isset( $_GET['state'] ) ) {
            $saved_state = get_transient( 'g_maps_oauth_state' );
            if ( $_GET['state'] !== $saved_state ) {
                return false;
            }
        }

        $token_url = 'https://oauth2.googleapis.com/token';

        $response = wp_remote_post( $token_url, array(
            'body' => array(
                'code'          => $code,
                'client_id'     => $creds['client_id'],
                'client_secret' => $creds['client_secret'],
                'redirect_uri'  => $redirect_uri,
                'grant_type'    => 'authorization_code',
            )
        ) );

        if ( is_wp_error( $response ) ) return false;

        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        
        if ( isset( $data['access_token'] ) ) {
            update_option( 'g_maps_access_token', $data['access_token'] );
            update_option( 'g_maps_token_expires', time() + $data['expires_in'] );
            if ( isset( $data['refresh_token'] ) ) {
                update_option( 'g_maps_refresh_token', $data['refresh_token'] );
            }
            return true;
        }
        return false;
    }

    public static function refresh_access_token() {
        $refresh_token = get_option( 'g_maps_refresh_token', '' );
        if ( empty( $refresh_token ) ) return false;

        $creds = self::get_credentials();
        if ( empty( $creds['client_id'] ) || empty( $creds['client_secret'] ) ) return false;

        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'body' => array(
                'client_id'     => $creds['client_id'],
                'client_secret' => $creds['client_secret'],
                'refresh_token' => $refresh_token,
                'grant_type'    => 'refresh_token',
            )
        ) );

        if ( is_wp_error( $response ) ) return false;

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset( $data['access_token'] ) ) {
            update_option( 'g_maps_access_token', $data['access_token'] );
            update_option( 'g_maps_token_expires', time() + $data['expires_in'] );
            return true;
        }
        return false;
    }

    public static function get_valid_access_token() {
        $token = get_option( 'g_maps_access_token', '' );
        $expires = get_option( 'g_maps_token_expires', 0 );

        if ( $expires && ( $expires - time() < 60 ) ) {
            if ( self::refresh_access_token() ) {
                $token = get_option( 'g_maps_access_token', '' );
            }
        }

        return $token;
    }

    // ========== НОВИЙ МЕТОД ДЛЯ СТВОРЕННЯ ПРОФІЛЮ В GOOGLE ==========
    public static function create_business_profile( $order_id ) {
        $token = self::get_valid_access_token();
        if ( empty( $token ) ) {
            return array( 'success' => false, 'message' => 'Немає дійсного токена доступу.' );
        }

        $biz_name = get_post_meta( $order_id, '_google_biz_name', true );
        $category = get_post_meta( $order_id, '_biz_category', true );
        $phone = get_post_meta( $order_id, '_biz_phone', true );
        $description = get_post_meta( $order_id, '_biz_description', true );
        $logo_id = get_post_meta( $order_id, '_biz_logo_attachment_id', true );
        $storefront_id = get_post_meta( $order_id, '_biz_storefront_attachment_id', true );

        // Дані для створення локації в Google My Business
        $location_data = array(
            'title' => $biz_name,
            'categories' => array(
                array( 'category' => $category )
            ),
            'phoneNumbers' => array(
                array(
                    'value' => $phone,
                    'type' => 'PRIMARY'
                )
            ),
            'storeCode' => 'WP-' . $order_id
        );

        // Якщо є опис - додаємо
        if ( ! empty( $description ) ) {
            $location_data['description'] = $description;
        }

        $api_url = 'https://mybusiness.googleapis.com/v4/accounts/{accountId}/locations';

        // ОТРИМУЄМО ACCOUNT ID (перший аккаунт у списку)
        $accounts_response = wp_remote_get( 'https://mybusiness.googleapis.com/v4/accounts', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            )
        ) );

        if ( is_wp_error( $accounts_response ) ) {
            return array( 'success' => false, 'message' => 'Помилка отримання акаунтів: ' . $accounts_response->get_error_message() );
        }

        $accounts_data = json_decode( wp_remote_retrieve_body( $accounts_response ), true );
        if ( empty( $accounts_data['accounts'] ) ) {
            return array( 'success' => false, 'message' => 'Не знайдено жодного акаунта Google My Business.' );
        }

        $account_id = $accounts_data['accounts'][0]['name']; // Наприклад: "accounts/123456789"

        // ВИКЛИКАЄМО API ДЛЯ СТВОРЕННЯ ЛОКАЦІЇ
        $create_url = str_replace( '{accountId}', $account_id, $api_url );

        $create_response = wp_remote_post( $create_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ),
            'body' => json_encode( $location_data )
        ) );

        if ( is_wp_error( $create_response ) ) {
            return array( 'success' => false, 'message' => 'Помилка створення локації: ' . $create_response->get_error_message() );
        }

        $response_code = wp_remote_retrieve_response_code( $create_response );
        $response_body = json_decode( wp_remote_retrieve_body( $create_response ), true );

        if ( $response_code === 200 || $response_code === 201 ) {
            // Зберігаємо Google Place ID
            if ( isset( $response_body['name'] ) ) {
                update_post_meta( $order_id, '_google_place_id', $response_body['name'] );
                update_post_meta( $order_id, '_payment_status', 'paid' );
            }
            return array( 'success' => true, 'data' => $response_body );
        } else {
            return array( 'success' => false, 'message' => 'Помилка API: ' . ( $response_body['error']['message'] ?? 'Невідома помилка' ) );
        }
    }
}