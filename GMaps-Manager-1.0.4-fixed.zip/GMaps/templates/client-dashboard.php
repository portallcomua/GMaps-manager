<?php
/**
 * Шаблон Кабінету Клієнта (з формою входу/реєстрації)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! is_user_logged_in() ) {
    ?>
    <div class="g-maps-client-container">
        <h2>🔐 Вхід для заповнення анкети</h2>
        <p>Будь ласка, увійдіть або зареєструйтеся, щоб заповнити анкету для налаштування Google Business Profile.</p>
        
        <div style="background: #f9f9f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <?php if ( get_option( 'g_maps_client_id', '' ) ) : ?>
                <div style="margin-bottom:15px;">
                    <div id="g-maps-google-login-button"></div>
                </div>
                <p style="text-align:center;color:#777;margin:10px 0;">або</p>
            <?php endif; ?>
            <?php
            wp_login_form( array(
                'redirect' => home_url( '/gmaps/' ),
                'label_username' => '📧 Email або логін',
                'label_password' => '🔒 Пароль',
                'label_log_in' => '🚪 Увійти',
                'remember' => true,
            ) );
            ?>
            <p style="margin-top: 15px;">
                <a href="<?php echo wp_registration_url(); ?>">📝 Зареєструватися</a> | 
                <a href="<?php echo wp_lostpassword_url(); ?>">❓ Забули пароль?</a>
            </p>
        </div>
        
        <p style="font-size: 14px; color: #666; text-align: center;">
            Після входу ви зможете заповнити анкету для створення Google Business Profile.
        </p>
    </div>
    <?php
    return;
}

$referrer_manager = isset( $_COOKIE['g_maps_ref_manager'] ) ? sanitize_text_field( $_COOKIE['g_maps_ref_manager'] ) : '';
$status = isset( $_GET['status'] ) ? $_GET['status'] : '';

if ( $status === 'success' ) : ?>
    <div style="background: #d4edda; border-left: 4px solid #28a745; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
        <strong>✅ Успішно!</strong> Вашу заявку прийнято. Менеджер зв'яжеться з вами найближчим часом.
    </div>
<?php elseif ( $status === 'duplicate' ) : ?>
    <div style="background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin-bottom: 20px; border-radius: 4px;">
        <strong>⚠️ Ви вже подавали заявку!</strong> Будь ласка, зачекайте на зв'язок з менеджером.
    </div>
<?php endif; ?>

<div class="g-maps-client-container">
    <h2>🗺️ Налаштування вашого Google Business Profile</h2>
    
    <div class="g-maps-notice">
        <h3>⚠️ Важлива інформація про модерацію Google</h3>
        <p>Створення бізнес-точок повністю контролюється Google. Заповнюйте анкету максимально точно.</p>
        <ul>
            <li><strong>Фото вивіски:</strong> Реальне фото фасаду знижує ризик блокування на 80%.</li>
            <li><strong>Відеоверифікація:</strong> Якщо Google попросить підтвердження, менеджер допоможе.</li>
        </ul>
    </div>

    <div class="g-maps-tabs">
        <button class="tab-btn active" onclick="openTab(event, 'step-auth')">1. Доступ</button>
        <button class="tab-btn" onclick="openTab(event, 'step-info')">2. Дані</button>
        <button class="tab-btn" onclick="openTab(event, 'step-media')">3. Медіа</button>
        <button class="tab-btn" onclick="openTab(event, 'step-payment')">4. Оплата</button>
    </div>

    <form id="g-maps-order-form" method="POST" enctype="multipart/form-data">
        <?php wp_nonce_field( 'g_maps_client_action', 'g_maps_client_nonce' ); ?>
        
        <input type="hidden" name="referrer_manager_id" value="<?php echo esc_attr( $referrer_manager ); ?>">
        
        <div id="step-auth" class="tab-content active">
            <h3>Зв'язок з вашим Google-акаунтом</h3>
            <p>Введіть назву компанії, якщо вона вже колись створювалась на картах:</p>
            <input type="text" name="google_biz_name" placeholder="Наприклад: Кав'ярня 'Арома' Київ" style="width: 100%; padding: 10px; box-sizing: border-box;">
            <br>
            <button type="button" class="button button-primary" style="margin-top: 10px;">🤖 Надати права менеджменту майстру</button>
            <p style="font-size: 12px; color: #666; margin-top: 10px;">*Запит надійде автоматично. Вам потрібно буде лише підтвердити його у своєму Google-акаунті.</p>
        </div>

        <div id="step-info" class="tab-content" style="display:none;">
            <h3>Основна інформація</h3>
            <p>
                <label><strong>Точна назва для Карт:</strong></label>
                <input type="text" name="biz_final_name" required>
            </p>
            <p>
                <label><strong>Категорія бізнесу:</strong></label>
                <input type="text" name="biz_category" placeholder="Наприклад: Салон краси, СТО, Кафе" required>
            </p>
            <p>
                <label><strong>Опис компанії (до 750 символів):</strong></label>
                <textarea name="biz_description" rows="4" placeholder="Опишіть ваші послуги..."></textarea>
            </p>
            <p>
                <label><strong>Телефон для клієнтів на Карті:</strong></label>
                <input type="tel" name="biz_phone" required>
            </p>
            <p>
                <label><strong>Графік роботи:</strong></label>
                <input type="text" name="biz_hours" placeholder="Пн-Пт: 09:00 - 18:00, Сб: 10:00 - 16:00">
            </p>
        </div>

        <div id="step-media" class="tab-content" style="display:none;">
            <h3>Завантаження фотоматеріалів</h3>
            <p>
                <label><strong>Логотип компанії:</strong></label>
                <input type="file" name="biz_logo" accept="image/*">
            </p>
            <p style="background: #f0f0f0; padding: 10px; border-radius: 4px;">
                <label><strong>📸 Фото вивіски або входу:</strong></label>
                <input type="file" name="biz_storefront" accept="image/*" capture="environment">
                <br><small style="color: #666;">*На смартфонах ця кнопка одразу запустить основну камеру.</small>
            </p>
        </div>

        <div id="step-payment" class="tab-content" style="display:none;">
            <h3>Фінальний крок: Оплата та відправка</h3>
            <p>Після успішної оплати ваша анкета миттєво з'явиться на робочому столі вашого менеджера.</p>
            
            <div class="payment-options">
                <?php 
                $payhip_url = defined( 'G_MAPS_PAYHIP_URL' ) ? G_MAPS_PAYHIP_URL : 'https://payhip.com/b/s12Lx';
                ?>
                <a href="<?php echo esc_url( $payhip_url ); ?>" 
                   target="_blank"
                   class="payhip-buy-button"
                   style="background: #007cba; color: #fff; padding: 14px 24px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold; text-align: center;">
                   💳 Оплатити послугу налаштування
                </a>
            </div>
            
            <br>
            <input type="submit" name="save_g_maps_order" class="button button-primary" value="🚀 Надіслати анкету майстру" style="font-size: 16px; padding: 12px 25px; background: #46b450; border: none; color: #fff; border-radius: 4px; cursor: pointer;">
        </div>
    </form>
</div>

<script>
function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tab-content");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tab-btn");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove("active");
        tablinks[i].style.background = "#f5f5f5";
    }
    document.getElementById(tabName).style.display = "block";
    if (evt && evt.currentTarget) {
        evt.currentTarget.classList.add("active");
        evt.currentTarget.style.background = "#007cba";
        evt.currentTarget.style.color = "#fff";
    }
}

document.addEventListener('DOMContentLoaded', function() {
    <?php if ( $status === 'success' ) : ?>
    var tabs = document.getElementsByClassName("tab-btn");
    if (tabs.length > 0) {
        tabs[tabs.length - 1].click();
    }
    <?php endif; ?>
});
</script>