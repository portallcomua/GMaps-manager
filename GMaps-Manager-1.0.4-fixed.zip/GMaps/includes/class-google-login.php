<?php
/**
 * Клас для входу через Google (One-Tap Login)
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GoogleLogin {

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
    }

    public function enqueue_scripts() {
        $post = get_post();
        $has_shortcode = $post && has_shortcode( (string) $post->post_content, 'g_maps_client_dashboard' );

        if ( is_page( 'gmaps' ) || $has_shortcode ) {
            wp_enqueue_script( 'g-maps-google-login', 'https://accounts.google.com/gsi/client', array(), null, true );
            wp_register_script( 'g-maps-login-inline', '', array( 'g-maps-google-login' ), G_MAPS_VERSION, true );
            wp_enqueue_script( 'g-maps-login-inline' );
            wp_add_inline_script( 'g-maps-login-inline', $this->get_login_js() );
        }
    }

    private function get_login_js() {
        $client_id = esc_js( get_option( 'g_maps_client_id', '' ) );
        $endpoint  = esc_url_raw( rest_url( 'gmaps/v1/google-login' ) );
        return "
        window.gMapsGoogleLoginCallback = function(response) {
            if (!response || !response.credential) { return; }
            fetch('{$endpoint}', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                credentials: 'same-origin',
                body: JSON.stringify({credential: response.credential})
            }).then(function(r){ return r.json(); }).then(function(data){
                if (data && data.success && data.redirect) { window.location.href = data.redirect; }
                else { alert('Не вдалося увійти через Google. Спробуйте звичайний вхід.'); }
            }).catch(function(){ alert('Помилка Google входу. Спробуйте звичайний вхід.'); });
        };
        window.gMapsInitGoogleButton = function() {
            if (!window.google || !google.accounts || !google.accounts.id || !'{$client_id}') { return; }
            var btn = document.getElementById('g-maps-google-login-button');
            if (!btn) { return; }
            google.accounts.id.initialize({client_id: '{$client_id}', callback: window.gMapsGoogleLoginCallback});
            google.accounts.id.renderButton(btn, {theme: 'outline', size: 'large', text: 'signin_with', locale: 'uk'});
        };
        document.addEventListener('DOMContentLoaded', function(){ setTimeout(window.gMapsInitGoogleButton, 300); });
        ";
    }

    public function register_routes() {
        register_rest_route( 'gmaps/v1', '/google-login', array(
            'methods' => 'POST',
            'callback' => array( $this, 'handle_google_login' ),
            'permission_callback' => '__return_true'
        ) );
    }

    public function handle_google_login( $request ) {
        $credential = $request->get_param( 'credential' );
        if ( empty( $credential ) ) {
            return new WP_REST_Response( array( 'error' => 'No credential' ), 400 );
        }

        $response = wp_remote_get( add_query_arg( 'id_token', rawurlencode( $credential ), 'https://oauth2.googleapis.com/tokeninfo' ) );
        if ( is_wp_error( $response ) ) {
            return new WP_REST_Response( array( 'error' => 'Invalid token' ), 400 );
        }

        $user_data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $user_data['email'] ) ) {
            return new WP_REST_Response( array( 'error' => 'No email' ), 400 );
        }

        $client_id = get_option( 'g_maps_client_id', '' );
        if ( ! empty( $client_id ) && isset( $user_data['aud'] ) && $user_data['aud'] !== $client_id ) {
            return new WP_REST_Response( array( 'error' => 'Wrong audience' ), 403 );
        }

        if ( isset( $user_data['email_verified'] ) && $user_data['email_verified'] !== 'true' && $user_data['email_verified'] !== true ) {
            return new WP_REST_Response( array( 'error' => 'Email not verified' ), 403 );
        }

        $email = $user_data['email'];
        $user = get_user_by( 'email', $email );

        if ( ! $user ) {
            $username = sanitize_user( explode( '@', $email )[0] );
            if ( username_exists( $username ) ) {
                $username = $username . '_' . rand( 100, 999 );
            }
            
            $password = wp_generate_password( 12, true, true );
            $user_id = wp_create_user( $username, $password, $email );
            
            if ( is_wp_error( $user_id ) ) {
                return new WP_REST_Response( array( 'error' => 'User creation failed' ), 400 );
            }
            
            $user = get_user_by( 'ID', $user_id );
            update_user_meta( $user_id, 'google_avatar', $user_data['picture'] ?? '' );
            update_user_meta( $user_id, 'google_verified_email', $user_data['email_verified'] ?? false );
        }

        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID );

        return new WP_REST_Response( array( 
            'success' => true, 
            'redirect' => home_url( '/gmaps/' ) 
        ), 200 );
    }
}

new GoogleLogin();