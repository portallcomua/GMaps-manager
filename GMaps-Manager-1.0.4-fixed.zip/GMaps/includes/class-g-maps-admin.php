<?php
/**
 * Клас керування кабінетом адміністратора
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GMapsAdmin {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_admin_menu_page' ) );
        add_action( 'admin_init', array( $this, 'handle_admin_settings_and_oauth' ) );
        add_action( 'admin_init', array( $this, 'handle_publish_to_google' ) );
        add_action( 'admin_init', array( $this, 'handle_transfer_ownership' ) );
        add_action( 'admin_init', array( $this, 'handle_search_location' ) );
        add_action( 'admin_init', array( $this, 'handle_request_ownership' ) );
    }

    public function add_admin_menu_page() {
        add_menu_page(
            'G-Maps Замовлення',
            '🛡️ G-Maps Панель',
            'manage_options',
            'g-maps-admin-panel',
            array( $this, 'render_admin_panel' ),
            'dashicons-location-alt',
            25
        );
    }

    public function handle_admin_settings_and_oauth() {
        if ( isset( $_POST['save_g_maps_settings'] ) && check_admin_referer( 'g_maps_settings_nonce' ) ) {
            update_option( 'g_maps_client_id', sanitize_text_field( $_POST['g_maps_client_id'] ) );
            update_option( 'g_maps_client_secret', sanitize_text_field( $_POST['g_maps_client_secret'] ) );
            wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&settings_saved=1' ) );
            exit;
        }

        if ( isset( $_GET['page'] ) && $_GET['page'] === 'g-maps-admin-panel' && isset( $_GET['code'] ) ) {
            $code = sanitize_text_field( $_GET['code'] );
            $success = GoogleMapsAPI::fetch_access_token( $code );
            wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&oauth=' . ( $success ? 'success' : 'failed' ) ) );
            exit;
        }
    }

    public function handle_publish_to_google() {
        if ( isset( $_POST['publish_to_google'] ) && isset( $_POST['order_id'] ) && check_admin_referer( 'g_maps_publish_action' ) ) {
            $order_id = intval( $_POST['order_id'] );
            
            $token = GoogleMapsAPI::get_valid_access_token();
            if ( empty( $token ) ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&publish=failed&reason=no_token' ) );
                exit;
            }

            $result = GoogleMapsAPI::create_business_profile( $order_id );
            
            if ( $result['success'] ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&publish=success' ) );
            } else {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&publish=failed&reason=' . urlencode( $result['message'] ) ) );
            }
            exit;
        }
    }

    public function handle_transfer_ownership() {
        if ( isset( $_POST['transfer_ownership'] ) && isset( $_POST['order_id'] ) && isset( $_POST['client_email'] ) ) {
            if ( ! check_admin_referer( 'g_maps_transfer_action' ) ) {
                wp_die( 'Security check failed' );
            }

            $order_id = intval( $_POST['order_id'] );
            $client_email = sanitize_email( $_POST['client_email'] );

            $token = GoogleMapsAPI::get_valid_access_token();
            if ( empty( $token ) ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&transfer=failed&reason=no_token' ) );
                exit;
            }

            $result = GoogleMapsAPI::transfer_ownership( $order_id, $client_email );

            if ( $result['success'] ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&transfer=success' ) );
            } else {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&transfer=failed&reason=' . urlencode( $result['message'] ) ) );
            }
            exit;
        }
    }

    public function handle_search_location() {
        if ( isset( $_POST['search_location'] ) && isset( $_POST['order_id'] ) && check_admin_referer( 'g_maps_search_action' ) ) {
            $order_id = intval( $_POST['order_id'] );
            
            $token = GoogleMapsAPI::get_valid_access_token();
            if ( empty( $token ) ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&search=failed&reason=no_token' ) );
                exit;
            }

            $result = GoogleMapsAPI::search_existing_location( $order_id );
            
            if ( $result['success'] && $result['found'] ) {
                update_post_meta( $order_id, '_google_place_id', $result['place_id'] );
                update_post_meta( $order_id, '_location_found', 'yes' );
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&search=found&title=' . urlencode( $result['title'] ) ) );
            } elseif ( $result['success'] && !$result['found'] ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&search=not_found' ) );
            } else {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&search=failed&reason=' . urlencode( $result['message'] ) ) );
            }
            exit;
        }
    }

    public function handle_request_ownership() {
        if ( isset( $_POST['request_ownership'] ) && isset( $_POST['order_id'] ) && check_admin_referer( 'g_maps_ownership_action' ) ) {
            $order_id = intval( $_POST['order_id'] );
            
            $token = GoogleMapsAPI::get_valid_access_token();
            if ( empty( $token ) ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&request=failed&reason=no_token' ) );
                exit;
            }

            $result = GoogleMapsAPI::request_ownership( $order_id );
            
            if ( $result['success'] ) {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&request=success' ) );
            } else {
                wp_redirect( admin_url( 'admin.php?page=g-maps-admin-panel&request=failed&reason=' . urlencode( $result['message'] ) ) );
            }
            exit;
        }
    }

    public function render_admin_panel() {
        $orders = get_posts( array(
            'post_type'   => 'g_maps_order',
            'post_status' => 'any',
            'numberposts' => -1,
        ) );

        $client_id = get_option( 'g_maps_client_id', '' );
        $client_secret = get_option( 'g_maps_client_secret', '' );
        $has_token = get_option( 'g_maps_access_token', '' ) ? '✅ Підключено' : '❌ Не підключено';
        $auth_url = GoogleMapsAPI::get_auth_url();

        include G_MAPS_TOOL_PATH . 'templates/admin-dashboard.php';
    }
}

new GMapsAdmin();