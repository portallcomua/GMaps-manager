<?php
/**
 * Клас для інтеграції з Google API
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GoogleMapsAPI {

    public static function get_credentials() {
        return array(
            'client_id'     => get_option( 'g_maps_client_id', '' ),
            'client_secret' => get_option( 'g_maps_client_secret', '' ),
        );
    }

    public static function get_auth_url() {
        $creds = self::get_credentials();
        if ( empty( $creds['client_id'] ) ) return '#';
        
        $state = wp_generate_password( 32, false );
        set_transient( 'g_maps_oauth_state', $state, 600 );

        $redirect_uri = admin_url( 'admin.php?page=g-maps-admin-panel' );
        
        $params = array(
            'client_id'       => $creds['client_id'],
            'redirect_uri'    => $redirect_uri,
            'response_type'   => 'code',
            'scope'           => 'https://www.googleapis.com/auth/business.manage',
            'access_type'     => 'offline',
            'prompt'          => 'consent',
            'state'           => $state
        );

        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query( $params );
    }

    public static function fetch_access_token( $code ) {
        $creds = self::get_credentials();
        $redirect_uri = admin_url( 'admin.php?page=g-maps-admin-panel' );

        if ( isset( $_GET['state'] ) ) {
            $saved_state = get_transient( 'g_maps_oauth_state' );
            if ( $_GET['state'] !== $saved_state ) {
                return false;
            }
        }

        $token_url = 'https://oauth2.googleapis.com/token';

        $response = wp_remote_post( $token_url, array(
            'body' => array(
                'code'          => $code,
                'client_id'     => $creds['client_id'],
                'client_secret' => $creds['client_secret'],
                'redirect_uri'  => $redirect_uri,
                'grant_type'    => 'authorization_code',
            )
        ) );

        if ( is_wp_error( $response ) ) return false;

        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        
        if ( isset( $data['access_token'] ) ) {
            update_option( 'g_maps_access_token', $data['access_token'] );
            update_option( 'g_maps_token_expires', time() + $data['expires_in'] );
            if ( isset( $data['refresh_token'] ) ) {
                update_option( 'g_maps_refresh_token', $data['refresh_token'] );
            }
            return true;
        }
        return false;
    }

    public static function refresh_access_token() {
        $refresh_token = get_option( 'g_maps_refresh_token', '' );
        if ( empty( $refresh_token ) ) return false;

        $creds = self::get_credentials();
        if ( empty( $creds['client_id'] ) || empty( $creds['client_secret'] ) ) return false;

        $response = wp_remote_post( 'https://oauth2.googleapis.com/token', array(
            'body' => array(
                'client_id'     => $creds['client_id'],
                'client_secret' => $creds['client_secret'],
                'refresh_token' => $refresh_token,
                'grant_type'    => 'refresh_token',
            )
        ) );

        if ( is_wp_error( $response ) ) return false;

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset( $data['access_token'] ) ) {
            update_option( 'g_maps_access_token', $data['access_token'] );
            update_option( 'g_maps_token_expires', time() + $data['expires_in'] );
            return true;
        }
        return false;
    }

    public static function get_valid_access_token() {
        $token = get_option( 'g_maps_access_token', '' );
        $expires = get_option( 'g_maps_token_expires', 0 );

        if ( $expires && ( $expires - time() < 60 ) ) {
            if ( self::refresh_access_token() ) {
                $token = get_option( 'g_maps_access_token', '' );
            }
        }

        return $token;
    }

    public static function create_business_profile( $order_id ) {
        $token = self::get_valid_access_token();
        if ( empty( $token ) ) {
            return array( 'success' => false, 'message' => 'Немає дійсного токена доступу.' );
        }

        $biz_name = get_post_meta( $order_id, '_biz_final_name', true );
        if ( empty( $biz_name ) ) {
            $biz_name = get_post_meta( $order_id, '_google_biz_name', true );
        }
        $category = get_post_meta( $order_id, '_biz_category', true );
        $phone = get_post_meta( $order_id, '_biz_phone', true );
        $description = get_post_meta( $order_id, '_biz_description', true );
        $logo_id = get_post_meta( $order_id, '_biz_logo_attachment_id', true );
        $storefront_id = get_post_meta( $order_id, '_biz_storefront_attachment_id', true );

        $location_data = array(
            'title' => $biz_name,
            'categories' => array(
                array( 'category' => $category )
            ),
            'phoneNumbers' => array(
                array(
                    'value' => $phone,
                    'type' => 'PRIMARY'
                )
            ),
            'storeCode' => 'WP-' . $order_id
        );

        if ( ! empty( $description ) ) {
            $location_data['description'] = $description;
        }

        $api_url = 'https://mybusiness.googleapis.com/v4/accounts/{accountId}/locations';

        $accounts_response = wp_remote_get( 'https://mybusiness.googleapis.com/v4/accounts', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            )
        ) );

        if ( is_wp_error( $accounts_response ) ) {
            return array( 'success' => false, 'message' => 'Помилка отримання акаунтів: ' . $accounts_response->get_error_message() );
        }

        $accounts_data = json_decode( wp_remote_retrieve_body( $accounts_response ), true );
        if ( empty( $accounts_data['accounts'] ) ) {
            return array( 'success' => false, 'message' => 'Не знайдено жодного акаунта Google My Business.' );
        }

        $account_id = $accounts_data['accounts'][0]['name'];

        $create_url = str_replace( '{accountId}', $account_id, $api_url );

        $create_response = wp_remote_post( $create_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ),
            'body' => json_encode( $location_data )
        ) );

        if ( is_wp_error( $create_response ) ) {
            return array( 'success' => false, 'message' => 'Помилка створення локації: ' . $create_response->get_error_message() );
        }

        $response_code = wp_remote_retrieve_response_code( $create_response );
        $response_body = json_decode( wp_remote_retrieve_body( $create_response ), true );

        if ( $response_code === 200 || $response_code === 201 ) {
            if ( isset( $response_body['name'] ) ) {
                update_post_meta( $order_id, '_google_place_id', $response_body['name'] );
                update_post_meta( $order_id, '_payment_status', 'paid' );
            }
            return array( 'success' => true, 'data' => $response_body );
        } else {
            return array( 'success' => false, 'message' => 'Помилка API: ' . ( $response_body['error']['message'] ?? 'Невідома помилка' ) );
        }
    }

    public static function transfer_ownership( $order_id, $client_email ) {
        $token = self::get_valid_access_token();
        if ( empty( $token ) ) {
            return array(
                'success' => false,
                'message' => 'Немає дійсного токена доступу. Авторизуйте Google акаунт в адмін-панелі.'
            );
        }

        $place_id = get_post_meta( $order_id, '_google_place_id', true );
        if ( empty( $place_id ) ) {
            return array(
                'success' => false,
                'message' => 'Заявка ще не опублікована в Google. Спочатку натисніть "В Google".'
            );
        }

        $already_transferred = get_post_meta( $order_id, '_ownership_transferred', true );
        if ( $already_transferred === 'yes' ) {
            return array(
                'success' => false,
                'message' => 'Права власності вже були передані цьому клієнту.'
            );
        }

        if ( ! is_email( $client_email ) ) {
            return array(
                'success' => false,
                'message' => 'Некоректна електронна адреса клієнта.'
            );
        }

        $api_url = "https://mybusiness.googleapis.com/v4/{$place_id}:transfer";

        $response = wp_remote_post( $api_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ),
            'body' => json_encode( array(
                'targetAccount' => $client_email
            ) )
        ) );

        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'message' => 'Помилка з\'єднання з Google API: ' . $response->get_error_message()
            );
        }

        $response_code = wp_remote_retrieve_response_code( $response );
        $response_body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $response_code === 200 || $response_code === 201 ) {
            update_post_meta( $order_id, '_ownership_transferred', 'yes' );
            update_post_meta( $order_id, '_ownership_transferred_to', $client_email );
            update_post_meta( $order_id, '_ownership_transferred_at', current_time( 'mysql' ) );

            return array(
                'success' => true,
                'message' => '✅ Запрошення на передачу прав надіслано на email: ' . $client_email . '. Клієнт має перейти за посиланням у листі та підтвердити.'
            );
        } else {
            $error_message = isset( $response_body['error']['message'] ) 
                ? $response_body['error']['message'] 
                : 'Невідома помилка Google API (код: ' . $response_code . ')';
            
            return array(
                'success' => false,
                'message' => '❌ Помилка передачі прав: ' . $error_message
            );
        }
    }

    public static function search_existing_location( $order_id ) {
        $token = self::get_valid_access_token();
        if ( empty( $token ) ) {
            return array(
                'success' => false,
                'message' => 'Немає дійсного токена доступу.'
            );
        }

        $biz_name = get_post_meta( $order_id, '_google_biz_name', true );
        $phone = get_post_meta( $order_id, '_biz_phone', true );
        
        if ( empty( $biz_name ) && empty( $phone ) ) {
            return array(
                'success' => false,
                'message' => 'Не вказано назву або телефон для пошуку.'
            );
        }

        $accounts_response = wp_remote_get( 'https://mybusiness.googleapis.com/v4/accounts', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            )
        ) );

        if ( is_wp_error( $accounts_response ) ) {
            return array(
                'success' => false,
                'message' => 'Помилка отримання акаунтів: ' . $accounts_response->get_error_message()
            );
        }

        $accounts_data = json_decode( wp_remote_retrieve_body( $accounts_response ), true );
        if ( empty( $accounts_data['accounts'] ) ) {
            return array(
                'success' => false,
                'message' => 'Не знайдено жодного акаунта Google My Business.'
            );
        }

        $account_id = $accounts_data['accounts'][0]['name'];

        $search_url = 'https://mybusiness.googleapis.com/v4/' . $account_id . '/locations:search';
        
        $search_body = array(
            'query' => $biz_name . ' ' . $phone
        );

        $search_response = wp_remote_post( $search_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ),
            'body' => json_encode( $search_body )
        ) );

        if ( is_wp_error( $search_response ) ) {
            return array(
                'success' => false,
                'message' => 'Помилка пошуку: ' . $search_response->get_error_message()
            );
        }

        $response_code = wp_remote_retrieve_response_code( $search_response );
        $response_body = json_decode( wp_remote_retrieve_body( $search_response ), true );

        if ( $response_code === 200 ) {
            if ( ! empty( $response_body['locations'] ) ) {
                $location = $response_body['locations'][0];
                return array(
                    'success' => true,
                    'found' => true,
                    'location' => $location,
                    'place_id' => $location['name'],
                    'title' => $location['title'] ?? 'Без назви',
                    'message' => '✅ Знайдено існуючу картку: ' . ($location['title'] ?? 'Без назви')
                );
            } else {
                return array(
                    'success' => true,
                    'found' => false,
                    'message' => '❌ Картку не знайдено. Створіть нову через "В Google".'
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'Помилка API: ' . ($response_body['error']['message'] ?? 'Невідома помилка')
            );
        }
    }

    public static function request_ownership( $order_id ) {
        $token = self::get_valid_access_token();
        if ( empty( $token ) ) {
            return array(
                'success' => false,
                'message' => 'Немає дійсного токена доступу.'
            );
        }

        $place_id = get_post_meta( $order_id, '_google_place_id', true );
        if ( empty( $place_id ) ) {
            return array(
                'success' => false,
                'message' => 'Спочатку знайдіть картку через "🔍 Знайти картку".'
            );
        }

        $account_id = explode( '/', $place_id );
        array_pop( $account_id );
        $account_id = implode( '/', $account_id );

        $api_url = 'https://mybusiness.googleapis.com/v4/' . $account_id . '/locations:requestAdminRights';
        
        $request_body = array(
            'locationName' => $place_id,
            'requestReason' => 'Клієнт замовив послугу покращення Google Business Profile через наш сервіс.'
        );

        $response = wp_remote_post( $api_url, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ),
            'body' => json_encode( $request_body )
        ) );

        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'message' => 'Помилка запиту прав: ' . $response->get_error_message()
            );
        }

        $response_code = wp_remote_retrieve_response_code( $response );
        $response_body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( $response_code === 200 || $response_code === 201 ) {
            update_post_meta( $order_id, '_ownership_requested', 'yes' );
            return array(
                'success' => true,
                'message' => '✅ Запит на права власності надіслано! Власник картки отримає лист від Google. Очікуйте підтвердження (до 7 днів).'
            );
        } else {
            $error_message = isset( $response_body['error']['message'] ) 
                ? $response_body['error']['message'] 
                : 'Невідома помилка (код: ' . $response_code . ')';
            
            return array(
                'success' => false,
                'message' => '❌ Помилка запиту прав: ' . $error_message
            );
        }
    }
}