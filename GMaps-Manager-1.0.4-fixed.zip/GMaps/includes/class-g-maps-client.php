<?php
/**
 * Клас керування кабінетом клієнта та реферальною системою
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class GMapsClient {

    public function __construct() {
        add_action( 'init', array( $this, 'register_orders_post_type' ) );
        add_action( 'wp', array( $this, 'catch_manager_referral' ) );
        add_action( 'wp_loaded', array( $this, 'handle_client_form_submission' ) );
        add_shortcode( 'g_maps_client_dashboard', array( $this, 'render_client_dashboard' ) );
    }

    public function register_orders_post_type() {
        register_post_type( 'g_maps_order', array(
            'labels' => array(
                'name'          => 'Заявки G-Maps',
                'singular_name' => 'Заявка G-Maps',
            ),
            'public'      => false,
            'show_ui'     => true,
            'supports'    => array( 'title', 'editor' ),
        ) );
    }

    public function catch_manager_referral() {
        if ( isset( $_GET['ref'] ) && ! headers_sent() ) {
            $manager_id = sanitize_text_field( $_GET['ref'] );
            setcookie( 'g_maps_ref_manager', $manager_id, time() + ( 30 * DAY_IN_SECONDS ), COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        }
    }

    public function render_client_dashboard() {
        ob_start();
        include G_MAPS_TOOL_PATH . 'templates/client-dashboard.php';
        return ob_get_clean();
    }

    public function handle_client_form_submission() {
        if ( ! isset( $_POST['save_g_maps_order'] ) || ! is_user_logged_in() ) {
            return;
        }

        if ( ! isset( $_POST['g_maps_client_nonce'] ) || ! wp_verify_nonce( $_POST['g_maps_client_nonce'], 'g_maps_client_action' ) ) {
            wp_die( 'Security check failed' );
        }

        $user_id  = get_current_user_id();
        $biz_name = isset( $_POST['biz_final_name'] ) ? sanitize_text_field( wp_unslash( $_POST['biz_final_name'] ) ) : '';

        $existing_orders = get_posts( array(
            'post_type'   => 'g_maps_order',
            'post_status' => 'any',
            'meta_key'    => '_client_user_id',
            'meta_value'  => $user_id,
            'numberposts' => 1,
        ) );

        if ( ! empty( $existing_orders ) ) {
            wp_redirect( add_query_arg( 'status', 'duplicate', wp_get_referer() ) );
            exit;
        }

        $manager_id = isset( $_POST['referrer_manager_id'] ) ? sanitize_text_field( $_POST['referrer_manager_id'] ) : '';
        if ( empty( $manager_id ) && isset( $_COOKIE['g_maps_ref_manager'] ) ) {
            $manager_id = sanitize_text_field( $_COOKIE['g_maps_ref_manager'] );
        }

        $order_id = wp_insert_post( array(
            'post_title'  => 'Заявка: ' . $biz_name . ' (Клієнт #' . $user_id . ')',
            'post_status' => 'pending',
            'post_type'   => 'g_maps_order',
        ) );

        if ( is_wp_error( $order_id ) ) return;

        update_post_meta( $order_id, '_google_biz_name', isset( $_POST['google_biz_name'] ) ? sanitize_text_field( wp_unslash( $_POST['google_biz_name'] ) ) : $biz_name );
        update_post_meta( $order_id, '_biz_final_name', $biz_name );
        update_post_meta( $order_id, '_biz_category', isset( $_POST['biz_category'] ) ? sanitize_text_field( wp_unslash( $_POST['biz_category'] ) ) : '' );
        update_post_meta( $order_id, '_biz_description', isset( $_POST['biz_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['biz_description'] ) ) : '' );
        update_post_meta( $order_id, '_biz_phone', isset( $_POST['biz_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['biz_phone'] ) ) : '' );
        update_post_meta( $order_id, '_biz_hours', isset( $_POST['biz_hours'] ) ? sanitize_text_field( wp_unslash( $_POST['biz_hours'] ) ) : '' );
        update_post_meta( $order_id, '_client_user_id', $user_id );
        update_post_meta( $order_id, '_payment_status', 'unpaid' );

        if ( ! empty( $manager_id ) ) {
            update_post_meta( $order_id, '_assigned_manager_id', $manager_id );
        }

        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );

        if ( ! empty( $_FILES['biz_logo']['name'] ) ) {
            $logo_id = media_handle_upload( 'biz_logo', $order_id );
            if ( ! is_wp_error( $logo_id ) ) {
                update_post_meta( $order_id, '_biz_logo_attachment_id', $logo_id );
            }
        }

        if ( ! empty( $_FILES['biz_storefront']['name'] ) ) {
            $storefront_id = media_handle_upload( 'biz_storefront', $order_id );
            if ( ! is_wp_error( $storefront_id ) ) {
                update_post_meta( $order_id, '_biz_storefront_attachment_id', $storefront_id );
            }
        }

        if ( ! headers_sent() ) {
            setcookie( 'g_maps_ref_manager', '', time() - YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        }

        wp_redirect( add_query_arg( 'status', 'success', wp_get_referer() ) );
        exit;
    }
}

new GMapsClient();